import React, { Component } from 'react';
import Form from './Form.js';

class userForm extends Component {
   render() {
      return (
         <div>
            <h2>User Form</h2>
             <Form/>
         </div>
      );
   }
}
export default userForm;